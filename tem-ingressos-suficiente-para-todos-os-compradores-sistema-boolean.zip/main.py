## armaenando condicoes

ingressos = 50
compradores = 250
tem_ingresso_suficiente = (ingressos >= compradores)
print(tem_ingresso_suficiente)